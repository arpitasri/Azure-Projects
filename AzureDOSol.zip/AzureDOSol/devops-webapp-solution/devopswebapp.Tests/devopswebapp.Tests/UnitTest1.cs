using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace devopswebapp.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
